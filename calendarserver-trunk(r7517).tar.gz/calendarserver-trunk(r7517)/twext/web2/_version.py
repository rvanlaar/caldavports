# This is an auto-generated file. Do not edit it.
from twisted.python import versions
version = versions.Version('twext.web2', 9, 0, 0)

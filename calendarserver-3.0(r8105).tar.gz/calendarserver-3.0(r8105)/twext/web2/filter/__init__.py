# -*- test-case-name: twext.web2.test.test_cgi -*-
# Copyright (c) 2001-2004 Twisted Matrix Laboratories.
# See LICENSE for details.

"""
Output filters.
"""

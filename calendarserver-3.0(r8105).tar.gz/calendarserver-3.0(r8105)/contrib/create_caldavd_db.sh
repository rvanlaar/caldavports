#!/bin/bash

/usr/sbin/calendarserver_bootstrap_database

exit 0
